from services.rental_system import RentalSystem
from models.customer import Customer
from models.vehicle import Bike, Car, SUV
from data.seed_data import load_seed_data
from utils.validator import positive_int

def main():
    system = RentalSystem()
    load_seed_data(system)

    while True:
        print("\n====== QUICKWHEELS VEHICLE RENTAL ======")
        print("1. Register customer")
        print("2. Add vehicle")
        print("3. View vehicles (sorted by rate)")
        print("4. Rent a vehicle")
        print("5. Return a vehicle")
        print("6. View rentals")
        print("7. Exit")
        
        choice = input("Enter choice: ")

        if choice == "1":
            c_id = input("ID: ")
            name = input("Name: ")
            age = int(input("Age: "))
            phone = input("Phone: ")
            lic = input("License (or None): ")
            wallet = float(input("Wallet: "))
            if lic.lower() == "none":
                lic = None
            system.customer_service.add(Customer(c_id, name, age, phone, lic, wallet))
        elif choice == "2":
            v_type = input("Type (Bike/Car/SUV): ")
            name = input("Name: ")
            rate = float(input("Daily rate: "))
            if v_type == "Bike":
                v = Bike(name, rate)
            elif v_type == "Car":
                v = Car(name, rate)
            elif v_type == "SUV":
                v = SUV(name, rate)
            else:
                continue
            system.vehicle_service.add(v)
        elif choice == "3":
            vehicles = system.vehicle_service.list()
            for v in sorted(vehicles):
                print(f"{v} - Rate: {v.daily_rate} - Available: {v.available}")
        elif choice == "4":
            c_id = input("Customer ID: ")
            v_id = input("Vehicle ID: ")
            days = input("Days: ")
            if positive_int(days):
                r = system.rental_service.rent(c_id, v_id, int(days))
                if r:
                    print(f"Rented successfully! Rental ID: {r.rental_id}")
                else:
                    print("Rental failed. Check availability, eligibility, or funds.")
            else:
                print("Days must be a positive integer.")
        elif choice == "5":
            r_id = input("Rental ID: ")
            if positive_int(r_id):
                days = int(input("Actual days: "))
                note = input("Damage note (leave empty if none): ")
                if not note:
                    note = None
                if system.rental_service.return_vehicle(int(r_id), days, note):
                    print("Vehicle returned successfully.")
                else:
                    print("Return failed.")
            else:
                print("Invalid Rental ID.")
        elif choice == "6":
            for r in system.rental_service.list():
                print(f"{r} - Status: {r.status}")
        elif choice == "7":
            rentals = system.rental_service.list()
            for r in rentals:
                del r
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()