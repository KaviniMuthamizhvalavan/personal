import pytest
from data.datastore import DATASTORE
from models.customer import Customer
from services.customer_service import CustomerService

@pytest.fixture(autouse=True)
def setup_teardown():
    DATASTORE["customers"].clear()
    DATASTORE["vehicles"].clear()
    DATASTORE["rentals"].clear()

def test_add_customer():
    service = CustomerService()
    c = Customer("C99", "Test Name", 20, "1234567890", "LIC123", 100)
    service.add(c)
    assert "C99" in DATASTORE["customers"]
    assert DATASTORE["customers"]["C99"].name == "Test Name"

def test_wallet_encapsulation():
    c = Customer("C99", "Test Name", 20, "1234567890", "LIC123", 100)
    assert c.pay(150) is False
    assert c.balance == 100
    with pytest.raises(AttributeError):
        _ = c._wallet