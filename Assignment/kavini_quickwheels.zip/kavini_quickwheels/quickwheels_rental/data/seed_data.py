from models.customer import Customer
from models.vehicle import Bike, Car, SUV
from services.rental_system import RentalSystem

def load_seed_data(system: RentalSystem):
    v1 = Bike("Honda Activa", 400, "B-101")
    v2 = Car("Maruti Swift", 1800, "C-201")
    v3 = SUV("Toyota Innova", 3500, "S-301")
    system.vehicle_service.add(v1)
    system.vehicle_service.add(v2)
    system.vehicle_service.add(v3)

    c1 = Customer("CU01", "Arjun", 24, "1234567890", "TN10-2021-0042", 5000)
    c2 = Customer("CU02", "Meera", 31, "0987654321", "TN22-2018-0913", 15000)
    c3 = Customer("CU03", "Rahul", 17, "1112223333", None, 2000)
    system.customer_service.add(c1)
    system.customer_service.add(c2)
    system.customer_service.add(c3)