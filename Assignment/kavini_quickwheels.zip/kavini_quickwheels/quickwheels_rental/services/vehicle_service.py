from data.datastore import DATASTORE

class VehicleService:
    def add(self, vehicle):
        DATASTORE["vehicles"][vehicle.vehicle_id] = vehicle

    def get(self, vehicle_id):
        return DATASTORE["vehicles"].get(vehicle_id)

    def list(self):
        return list(DATASTORE["vehicles"].values())

    def delete(self, vehicle_id):
        if vehicle_id in DATASTORE["vehicles"]:
            del DATASTORE["vehicles"][vehicle_id]

    def apply_festival_offer(self, vehicle_id, pct):
        vehicle = self.get(vehicle_id)
        if vehicle:
            setattr(vehicle, "festival_offer", pct)