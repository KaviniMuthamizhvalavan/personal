from data.datastore import DATASTORE

class CustomerService:
    def add(self, customer):
        DATASTORE["customers"][customer.person_id] = customer

    def get(self, customer_id):
        return DATASTORE["customers"].get(customer_id)

    def list(self):
        return list(DATASTORE["customers"].values())

    def update_phone(self, customer_id, phone):
        customer = self.get(customer_id)
        if customer:
            customer.phone = phone

    def delete(self, customer_id):
        if customer_id in DATASTORE["customers"]:
            del DATASTORE["customers"][customer_id]