from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class BookBase(BaseModel):
    title: str
    author: str
    genre: Optional[str] = None
    status: Optional[str] = "available"

class BookCreate(BookBase):
    pass

class BookUpdate(BaseModel):
    title: Optional[str] = None
    author: Optional[str] = None
    genre: Optional[str] = None
    status: Optional[str] = None

class BookResponse(BookBase):
    id: int
    added_at: datetime

    class Config:
        from_attributes = True