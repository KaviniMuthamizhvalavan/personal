import requests

BASE_URL = "https://fakestoreapi.com/products"
# Activity 1: View All Products (GET)
def view_all_products():
    print("--- Activity 1: Fetching All Products ---")
    response = requests.get(BASE_URL)
    
    if response.status_code == 200:
        products = response.json()
        for product in products[:5]:  
            print(f"ID: {product.get('id')}")
            print(f"Title: {product.get('title')}")
            print(f"Price: ${product.get('price')}")
            print(f"Category: {product.get('category')}")
            print("-" * 30)
    else:
        print(f"Failed to fetch products. Status code: {response.status_code}")
    print("\n")

# Activity 2: Add a New Product (POST)
def add_new_product():
    print("--- Activity 2: Adding a New Product ---")
    new_product_data = {
        "title": "Python Programming Book",
        "price": 499,
        "description": "Learn Python from beginner to advanced",
        "image": "https://i.pravatar.cc",
        "category": "books"
    }
    
    response = requests.post(BASE_URL, json=new_product_data)
    
    if response.status_code in [200, 201]:
        print("Response received from server:")
        print(response.json())
    else:
        print(f"Failed to add product. Status code: {response.status_code}")
    print("\n")

# Activity 3: Update an Existing Product (PUT)
def update_product():
    print("--- Activity 3: Updating Product ID 1 ---")
    updated_product_data = {
        "title": "Python Programming Book - Second Edition",
        "price": 599,
        "description": "Updated edition with FastAPI",
        "image": "https://i.pravatar.cc",
        "category": "books"
    }
    
    url = f"{BASE_URL}/1"
    response = requests.put(url, json=updated_product_data)
    
    if response.status_code == 200:
        print("Updated response received from server:")
        print(response.json())
    else:
        print(f"Failed to update product. Status code: {response.status_code}")
    print("\n")

# Activity 4: Delete a Product (DELETE)

def delete_product():
    print("--- Activity 4: Deleting Product ID 1 ---")
    url = f"{BASE_URL}/1"
    response = requests.delete(url)
    
    if response.status_code == 200:
        print("Deleted product details returned by server:")
        print(response.json())
    else:
        print(f"Failed to delete product. Status code: {response.status_code}")
    print("\n")

# Execution
if __name__ == "__main__":
    view_all_products()
    add_new_product()
    update_product()
    delete_product()