from typing import TypedDict, Union, Sequence, Callable

# Part 1: Book Information (TypedDict)

class Book(TypedDict):
    id: int
    title: str
    author: str
    publication_year: int
    category: str
    is_available: bool

# Part 2: Membership Types (Union)

MemberID = Union[int, str]

def validate_member(member_id: MemberID, member_type: str) -> None:
    print(f"--- Validating Member ---")
    print(f"Member Type: {member_type}")
    print(f"Processing ID: {member_id} (Type: {type(member_id).__name__})")
    print("Member successfully validated.\n")

# Part 3: Display Available Books (Sequence)

def display_available_books(books: Sequence[Book]) -> None:
    print(f"--- Displaying Available Books ---")
    for book in books:
        if book['is_available']:
            print(f"Title: {book['title']} | Author: {book['author']}")
    print("\n")

# Part 4: Notification Service (Callable)

NotificationMethod = Callable[[str, str], None]

def send_email(member_name: str, message: str) -> None:
    print(f"[EMAIL] Sent to {member_name}: {message}")

def send_sms(member_name: str, message: str) -> None:
    print(f"[SMS] Sent to {member_name}: {message}")

def send_whatsapp(member_name: str, message: str) -> None:
    print(f"[WhatsApp] Sent to {member_name}: {message}")

def process_book_issue(member_name: str, book_title: str, notify_fn: NotificationMethod) -> None:
    print(f"--- Processing Book Issue ---")
    message = f"The book '{book_title}' has been successfully issued to you."
    notify_fn(member_name, message)
    print("\n")



# Execution

if __name__ == "__main__":
    
    book1: Book = {
        "id": 101,
        "title": "The Pythonic Way",
        "author": "Alice Raymond",
        "publication_year": 2024,
        "category": "Technology",
        "is_available": True
    }
    
    book2: Book = {
        "id": 102,
        "title": "Introduction to Algorithms",
        "author": "Bob Smith",
        "publication_year": 2021,
        "category": "Education",
        "is_available": True
    }

    validate_member(12345, "Student")       
    validate_member("FAC-99812", "Faculty")

    book_list: list[Book] = [book1]
    book_tuple: tuple[Book, ...] = (book2,)
    
    display_available_books(book_list)
    display_available_books(book_tuple)

    process_book_issue("Jane Doe", book1["title"], send_email)
    process_book_issue("Professor John", book2["title"], send_whatsapp)