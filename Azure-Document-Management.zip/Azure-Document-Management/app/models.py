from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.orm import declarative_base
from sqlalchemy.sql import func

Base = declarative_base()

class Document(Base):
    __tablename__ = "Documents"

    document_id = Column(Integer, primary_key=True, index=True)
    file_name = Column(String(255), nullable=False)
    blob_url = Column(String(500), nullable=False)
    uploaded_by = Column(String(100))
    upload_date = Column(DateTime, server_default=func.now())
    file_type = Column(String(50))