from pydantic import BaseModel
from datetime import datetime

class DocumentResponse(BaseModel):
    document_id: int
    file_name: str
    blob_url: str
    uploaded_by: str | None
    upload_date: datetime
    file_type: str

    class Config:
        from_attributes = True