from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from azure.storage.blob import BlobServiceClient
from sqlalchemy import text
from dotenv import load_dotenv
from app.database import SessionLocal
from azure.storage.blob import generate_blob_sas, BlobSasPermissions
from datetime import datetime, timedelta
import os

load_dotenv()

app = FastAPI(title="Smart Document Management API")

# Serve frontend
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def home():
    return FileResponse("static/index.html")


# Azure Blob Storage Configuration
connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
container_name = os.getenv("AZURE_CONTAINER_NAME")

blob_service_client = BlobServiceClient.from_connection_string(
    connection_string
)


# Upload Document
@app.post("/upload")
async def upload_document(
    file: UploadFile = File(...),
    uploaded_by: str = Form(...)
):

    try:

        blob_client = blob_service_client.get_blob_client(
            container=container_name,
            blob=file.filename
        )

        file_data = await file.read()

        blob_client.upload_blob(file_data, overwrite=True)

        db = SessionLocal()

        db.execute(
            text("""
            INSERT INTO Documents
            (file_name, blob_url, uploaded_by, file_type)
            VALUES
            (:file_name, :blob_url, :uploaded_by, :file_type)
            """),
            {
                "file_name": file.filename,
                "blob_url": blob_client.url,
                "uploaded_by": uploaded_by,
                "file_type": file.content_type
            }
        )

        db.commit()
        db.close()

        return {
            "message": "Uploaded Successfully",
            "blob_url": blob_client.url
        }

    except Exception as e:
        return {"error": str(e)}


# View All Documents
@app.get("/documents")
def get_all_documents():

    db = SessionLocal()

    result = db.execute(text("SELECT * FROM Documents"))

    documents = []

    for row in result:

        documents.append({

            "document_id": row.document_id,
            "file_name": row.file_name,
            "blob_url": row.blob_url,
            "uploaded_by": row.uploaded_by,
            "upload_date": str(row.upload_date),
            "file_type": row.file_type

        })

    db.close()

    return documents


# View Document By ID
@app.get("/documents/{document_id}")
def get_document(document_id: int):

    db = SessionLocal()

    result = db.execute(
        text("SELECT * FROM Documents WHERE document_id=:id"),
        {"id": document_id}
    )

    row = result.fetchone()

    db.close()

    if row is None:
        raise HTTPException(status_code=404, detail="Document not found")

    return {

        "document_id": row.document_id,
        "file_name": row.file_name,
        "blob_url": row.blob_url,
        "uploaded_by": row.uploaded_by,
        "upload_date": str(row.upload_date),
        "file_type": row.file_type

    }


@app.get("/share/{document_id}")
def generate_share_link(document_id: int, minutes: int = 5):

    db = SessionLocal()

    result = db.execute(
        text("SELECT file_name FROM Documents WHERE document_id=:id"),
        {"id": document_id}
    )

    row = result.fetchone()

    db.close()

    if row is None:
        raise HTTPException(status_code=404, detail="Document not found")

    sas_token = generate_blob_sas(
        account_name=os.getenv("AZURE_STORAGE_ACCOUNT"),
        container_name=container_name,
        blob_name=row.file_name,
        account_key=os.getenv("AZURE_STORAGE_KEY"),
        permission=BlobSasPermissions(read=True),
        expiry=datetime.utcnow() + timedelta(minutes=minutes)
    )

    url = (
        f"https://{os.getenv('AZURE_STORAGE_ACCOUNT')}.blob.core.windows.net/"
        f"{container_name}/{row.file_name}?{sas_token}"
    )

    return {
        "share_url": url,
        "expires_in_minutes": minutes
    }
    
# Download Document
@app.get("/download/{document_id}")
def download_document(document_id: int):

    db = SessionLocal()

    result = db.execute(
        text("SELECT blob_url FROM Documents WHERE document_id=:id"),
        {"id": document_id}
    )

    row = result.fetchone()

    db.close()

    if row is None:
        raise HTTPException(status_code=404, detail="Document not found")

    return RedirectResponse(url=row.blob_url)


# Delete Document
@app.delete("/documents/{document_id}")
def delete_document(document_id: int):

    db = SessionLocal()

    result = db.execute(
        text("SELECT file_name FROM Documents WHERE document_id=:id"),
        {"id": document_id}
    )

    row = result.fetchone()

    if row is None:
        db.close()
        raise HTTPException(status_code=404, detail="Document not found")

    blob_client = blob_service_client.get_blob_client(
        container=container_name,
        blob=row.file_name
    )

    blob_client.delete_blob()

    db.execute(
        text("DELETE FROM Documents WHERE document_id=:id"),
        {"id": document_id}
    )

    db.commit()
    db.close()

    return {
        "message": "Document Deleted Successfully"
    }