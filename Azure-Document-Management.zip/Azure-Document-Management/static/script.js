const API = "http://127.0.0.1:8000";

window.onload = () => {
    loadDocuments();
};

async function uploadDocument() {

    const file = document.getElementById("file").files[0];
    const uploadedBy = document.getElementById("uploadedBy").value.trim();

    if (!uploadedBy) {
        alert("Please enter your name.");
        return;
    }

    if (!file) {
        alert("Please choose a document.");
        return;
    }

    const button = document.querySelector(".upload-btn");
    button.innerHTML = "Uploading...";
    button.disabled = true;

    const formData = new FormData();
    formData.append("file", file);
    formData.append("uploaded_by", uploadedBy);

    try {

        const response = await fetch(`${API}/upload`, {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        if (response.ok) {

            alert("✅ Document uploaded successfully.");

            document.getElementById("uploadedBy").value = "";
            document.getElementById("file").value = "";

            loadDocuments();

        } else {

            alert(data.error || "Upload failed.");

        }

    } catch (error) {

        console.error(error);
        alert("Unable to connect to server.");

    }

    button.innerHTML = "⬆ Upload Document";
    button.disabled = false;

}

async function loadDocuments() {

    try {

        const response = await fetch(`${API}/documents`);
        const documents = await response.json();

        const tbody = document.getElementById("documents");

        if (documents.length === 0) {

            tbody.innerHTML = `
            <tr>
                <td colspan="6">No documents uploaded.</td>
            </tr>
            `;

            return;
        }

        let html = "";

        documents.forEach(doc => {

            const type = getFileType(doc.file_name);

            html += `
            <tr>

                <td>${doc.document_id}</td>

                <td>
                    <strong>${doc.file_name}</strong><br>
                    <span class="file-type">${type}</span>
                </td>

                <td>${doc.uploaded_by}</td>

                <td>
                    <a href="${API}/download/${doc.document_id}" target="_blank">
                        ⬇ Download
                    </a>
                </td>

                <td>
                    <button
                        class="share-btn"
                        onclick="shareDocument(${doc.document_id})">
                        🔗 Share
                    </button>
                </td>

                <td>
                    <button
                        class="delete-btn"
                        onclick="deleteDocument(${doc.document_id})">
                        🗑 Delete
                    </button>
                </td>

            </tr>
            `;

        });

        tbody.innerHTML = html;

    }
    catch (error) {

        console.error(error);

    }

}

async function shareDocument(id) {

    try {

        const response = await fetch(`${API}/share/${id}?minutes=5`);

        const data = await response.json();

        if (!response.ok) {

            alert(data.detail || "Unable to generate share link.");
            return;

        }

        await navigator.clipboard.writeText(data.share_url);

        alert("🔗 Secure Share Link copied to clipboard!");

    }
    catch (error) {

        console.error(error);

        alert("Unable to generate share link.");

    }

}

async function deleteDocument(id) {

    if (!confirm("Are you sure you want to delete this document?"))
        return;

    try {

        const response = await fetch(`${API}/documents/${id}`, {
            method: "DELETE"
        });

        const data = await response.json();

        alert(data.message);

        loadDocuments();

    }
    catch (error) {

        console.error(error);

        alert("Delete failed.");

    }

}

function getFileType(filename) {

    const ext = filename.split(".").pop().toLowerCase();

    if (ext === "pdf")
        return "📄 PDF";

    if (["png","jpg","jpeg","gif","bmp","webp"].includes(ext))
        return "🖼 Image";

    if (["doc","docx"].includes(ext))
        return "📝 Word";

    if (["xls","xlsx"].includes(ext))
        return "📊 Excel";

    if (["ppt","pptx"].includes(ext))
        return "📽 PPT";

    return "📁 File";
}