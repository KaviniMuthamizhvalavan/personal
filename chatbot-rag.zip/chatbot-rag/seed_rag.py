import os
from dotenv import load_dotenv
load_dotenv()

from app.rag_service import index_pdf_document

if __name__ == "__main__":
    pdf_target = "Python_Content_Manual.pdf"
    
    if os.path.exists(pdf_target):
        print(f"Found {pdf_target}, starting database indexing processing...")
        index_pdf_document(pdf_target)
    else:
        print(f"Could not find document file at target path: {pdf_target}")