from pydantic import BaseModel
from datetime import datetime

# Input structure from Frontend
class ChatQuery(BaseModel):
    session_id: str
    message: str

# Individual message format inside history
class MessageResponse(BaseModel):
    role: str
    content: str
    timestamp: datetime

    class Config:
        from_attributes = True

# Standard structural wrapper for server response
class ChatResponse(BaseModel):
    session_id: str
    response: str