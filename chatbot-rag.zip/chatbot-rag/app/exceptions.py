from fastapi import HTTPException, status

class APIException(HTTPException):
    def __init__(self, detail: str = "Failed to communicate with the AI engine"):
        super().__init__(status_code=status.HTTP_502_BAD_GATEWAY, detail=detail)