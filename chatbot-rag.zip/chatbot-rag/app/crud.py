from sqlalchemy.orm import Session
from app.models import ChatMessage

def get_chat_history(db: Session, session_id: str):
    """Fetches full history for a single session, ordered by time."""
    return db.query(ChatMessage)\
             .filter(ChatMessage.session_id == session_id)\
             .order_by(ChatMessage.timestamp.asc())\
             .all()

def save_message(db: Session, session_id: str, role: str, content: str):
    """Persists a single message entity."""
    db_message = ChatMessage(session_id=session_id, role=role, content=content)
    db.add(db_message)
    db.commit()
    db.refresh(db_message)
    return db_message