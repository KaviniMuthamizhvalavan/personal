import os
import uuid
import requests
import chromadb
from pathlib import Path
from pypdf import PdfReader

# 1. Configuration loading matching your API pattern
GATEWAY_URL = os.getenv("GATEWAY_URL", "https://keygateway1.arshnivlabs.com")
LEARNER_KEY = os.getenv("LEARNER_KEY")

# 2. Setup Persistent ChromaDB inside your project directory
# This ensures data isn't wiped every time the FastAPI app reloads
DB_DIR = Path(__file__).parent.parent / "chroma_db"
chroma_client = chromadb.PersistentClient(path=str(DB_DIR))

# Explicitly use cosine distance to get bounded distance metrics
collection = chroma_client.get_or_create_collection(
    name="rag_collection", 
    metadata={"hnsw:space": "cosine"}
)

def get_embedding(text: str) -> list[float]:
    """Retrieves embedding vector from the network gateway."""
    if not LEARNER_KEY:
        raise ValueError("LEARNER_KEY environment variable is missing.")
        
    headers = {
        "Authorization": f"Bearer {LEARNER_KEY}",
        "Content-Type": "application/json",
    }
    
    response = requests.post(
        f"{GATEWAY_URL.rstrip('/')}/v1/embeddings",
        headers=headers,
        json={"input": text},
        timeout=30,
    )
    response.raise_for_status()
    return response.json()["data"][0]["embedding"]

def retrieve_context(query: str, top_k: int = 3) -> tuple[list[str], float]:
    """Queries ChromaDB collection and calculates a 0-100% confidence score."""
    try:
        query_embedding = get_embedding(query)
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
        )
        
        docs = results["documents"][0] if results["documents"] else []
        distances = results["distances"][0] if (results["distances"] and results["distances"][0]) else []
        
        if not docs or not distances:
            return [], 0.0
            
        # Cosine distance to similarity percentage mapping
        best_distance = distances[0]
        similarity_percentage = max(0.0, (1.0 - best_distance) * 100)
        
        return docs, similarity_percentage
    except Exception as e:
        print(f"ChromaDB lookup error: {e}")
        return [], 0.0

def index_pdf_document(pdf_path: str | Path):
    """Utility function to process and index a PDF cleanly."""
    reader = PdfReader(str(pdf_path))
    pages = [p.extract_text() for p in reader.pages if p.extract_text()]
    text = "\n".join(pages)
    
    # Simple chunking logic matching your setup
    chunk_size, overlap = 1000, 200
    chunks, start = [], 0
    while start < len(text):
        chunks.append(text[start : start + chunk_size])
        start += chunk_size - overlap
        
    print(f"Indexing {len(chunks)} chunks into ChromaDB...")
    for chunk in chunks:
        embedding = get_embedding(chunk)
        collection.add(
            ids=[str(uuid.uuid4())],
            documents=[chunk],
            embeddings=[embedding],
        )
    print("Indexing completely finished!")