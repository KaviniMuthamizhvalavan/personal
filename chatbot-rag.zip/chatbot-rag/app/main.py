from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from app.database import engine, Base, get_db
from app.schemas import ChatQuery, ChatResponse
from app import crud, utils
from dotenv import load_dotenv

load_dotenv()

# Automatically create database tables if they do not exist
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Context-Isolated Memory Chatbot Backend")

# Enable CORS so your frontend can communicate with the local server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Tighten this up for production deployment
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/chat", response_model=ChatResponse)
def handle_chat_query(payload: ChatQuery, db: Session = Depends(get_db)):
    # 1. Store the user's incoming query in memory database immediately
    crud.save_message(
        db=db, 
        session_id=payload.session_id, 
        role="user", 
        content=payload.message
    )

    # 2. Call utility layer to pull history, execute query
    ai_response_text = utils.generate_ai_response(
        db=db, 
        session_id=payload.session_id, 
        new_user_message=payload.message
    )

    # 3. Store the AI generated answer inside memory database
    crud.save_message(
        db=db, 
        session_id=payload.session_id, 
        role="assistant", 
        content=ai_response_text
    )

    # 4. Return structural compliance to the frontend
    return ChatResponse(session_id=payload.session_id, response=ai_response_text)