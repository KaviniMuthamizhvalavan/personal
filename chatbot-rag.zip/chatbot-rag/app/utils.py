import os
import requests
from sqlalchemy.orm import Session
from app.crud import get_chat_history
from app.exceptions import APIException
from app.rag_service import retrieve_context 

def generate_ai_response(db: Session, session_id: str, new_user_message: str) -> str:
    """Gets history, runs RAG confidence routing, and hits the authorized gateway."""
    
    # 1. Fetch the environment variables
    gateway_url = os.getenv("GATEWAY_URL")  
    learner_key = os.getenv("LEARNER_KEY")
    
    if not gateway_url or not learner_key:
        raise APIException("Gateway target configurations or LearnerKey is missing.")

    # --- NEW: STEP 2. Run RAG evaluation logic ---
    docs, confidence = retrieve_context(new_user_message)
    print(f"[RAG Route Engine] Match similarity rating: {confidence:.2f}%")

    # Determine system core prompting instructions using the 3-tier rules
    if confidence > 50.0:
        # Tier 1: More than 50% -> Pure RAG
        system_instruction = (
            "You are a helpful assistant. You must answer questions using ONLY the retrieved "
            "document excerpts provided. If the answer is not present, respond with: "
            "'I could not find the answer in the document.'"
        )
        context_str = "\n\n---\n\n".join(docs)
        final_user_content = f"Context:\n{context_str}\n\nQuestion:\n{new_user_message}"
        
    elif 30.0 <= confidence <= 50.0:
        # Tier 2: 30% to 50% -> 50% RAG / 50% LLM General Knowledge
        system_instruction = (
            "You are a helpful assistant blending document context with your general knowledge. "
            "You are provided with partial document context below. Use it to form 50% of your answer, "
            "and fill in the remaining gaps using your own general knowledge where the document lacks detail."
        )
        context_str = "\n\n---\n\n".join(docs)
        final_user_content = f"Partial Context:\n{context_str}\n\nQuestion:\n{new_user_message}"
        
    else:
        # Tier 3: Less than 30% -> Pure LLM
        system_instruction = "You are a helpful AI assistant. Answer the user's question directly using your general knowledge."
        final_user_content = new_user_message

    # 3. Fetch historical context for THIS session only
    history = get_chat_history(db, session_id)

    # 4. Build standard chat history payload array starting with our custom system rule
    messages_payload = [{"role": "system", "content": system_instruction}]
    
    for msg in history:
        messages_payload.append({"role": msg.role, "content": msg.content})

    # 5. Append current user message (packed with context if matching Tiers 1 or 2)
    messages_payload.append({"role": "user", "content": final_user_content})

    # 6. Construct Gateway specific headers and payload
    headers = {
        "Authorization": f"Bearer {learner_key}", 
        "Content-Type": "application/json"
    }

    payload = {
        "messages": messages_payload
    }

    try:
        # 7. Append the required endpoint path to the base URL
        full_endpoint_url = f"{gateway_url.rstrip('/')}/v1/chat/completions"
        
        response = requests.post(full_endpoint_url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        ai_reply = data["choices"][0]["message"]["content"]
        return ai_reply
        
    except Exception as e:
        print(f"Error calling Gateway API: {e}")
        raise APIException(f"Gateway routing error: {str(e)}")