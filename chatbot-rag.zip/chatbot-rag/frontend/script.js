// Base configuration endpoint targeting the local FastAPI engine
const API_URL = "http://127.0.0.1:8000/api/chat";

// DOM References
const chatBox = document.getElementById("chat-box");
const chatForm = document.getElementById("chat-form");
const userInput = document.getElementById("user-input");
const newChatBtn = document.getElementById("new-chat-btn");
const sessionDisplay = document.getElementById("session-display");

let currentSessionId = "";

// Helper: Generates a crypto-secure unique UUID for separating session scope
function generateSessionId() {
    return 'session-' + crypto.randomUUID();
}

// Initializing or resetting the visual chat scope
function initNewChatSession() {
    currentSessionId = generateSessionId();
    sessionDisplay.textContent = currentSessionId;
    
    // Wipe previous chat views clean without calling server data
    chatBox.innerHTML = `
        <div class="message system-message">
            New session started! Context memory is active for this isolated instance.
        </div>
    `;
}

// Appends message block UI nodes to viewport
function appendMessage(role, text) {
    const msgDiv = document.createElement("div");
    msgDiv.classList.add("message", `${role}-message`);
    msgDiv.textContent = text;
    chatBox.appendChild(msgDiv);
    
    // Dynamic scroll handling to match rapid data insertions
    chatBox.scrollTop = chatBox.scrollHeight;
    return msgDiv;
}

// Form Submission intercept processing payload delivery
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const text = userInput.value.trim();
    if (!text) return;

    // 1. Output the user message cleanly into viewport
    appendMessage("user", text);
    userInput.value = ""; // Clear active input bar immediately

    // 2. Add visual buffer placeholder for incoming stream asynchronous delay
    const loadingBubble = appendMessage("loading", "Thinking...");

    try {
        // 3. Fire structural payload matching backend schemas mapping parameters
        const response = await fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                session_id: currentSessionId,
                message: text
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP network anomaly error Status: ${response.status}`);
        }

        const data = await response.json();
        
        // Remove loading state indicator
        loadingBubble.remove();

        // 4. Print dynamic AI generated string back out to window view
        appendMessage("ai", data.response);

    } catch (error) {
        console.error("Transmission Pipeline Error:", error);
        loadingBubble.remove();
        appendMessage("system", `System failure connecting to backend host engine: ${error.message}`);
    }
}

// Active Event Listeners binding operations
chatForm.addEventListener("submit", handleFormSubmit);
newChatBtn.addEventListener("click", initNewChatSession);

// Bootstrap runtime initialization lifecycle trigger
document.addEventListener("DOMContentLoaded", initNewChatSession);