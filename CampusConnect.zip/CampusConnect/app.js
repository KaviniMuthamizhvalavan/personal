import {
  viewAllPosts,
  viewSinglePost,
  createPost,
  updatePost,
  deletePost,
  searchByUsername,
  searchByHashtag,
  filterByCategory,
  sortByLikes,
  trendingPosts,
  searchContent,
  filterHighLikes,
  displayLatestPosts,
  likePost,
  searchAndFilter
} from './controllers/postController.js';

async function runDashboardTesting() {
  console.log("=== Starting CampusConnect API Activity Run ===");

  // Activity 1: View All
  await viewAllPosts();

  // Activity 2: View Single Post (Targeting ID 3)
  await viewSinglePost('3');

  // Activity 3: Create New Post
  const newPostData = {
    username: "sophia",
    content: "Node.js APIs are awesome",
    category: "Programming",
    likes: 0,
    hashtags: "#nodejs"
  };
  await createPost(newPostData);

  // Activity 4: Update Existing Post (Targeting ID 2)
  const updatedPostData = {
    username: "emma",
    content: "Morning workout completed! Hit a new personal record!",
    category: "Fitness & Health",
    likes: 90,
    hashtags: "#fitness"
  };
  await updatePost('2', updatedPostData);

  // Activity 5: Delete Post (Targeting ID 4)
  await deletePost('4');

  // Activity 6: Search by Username
  await searchByUsername('john');

  // Activity 7: Search by Hashtag
  await searchByHashtag('#AI');

  // Activity 8: Filter by Category
  await filterByCategory('Programming');

  // Activity 9: Sort by Likes
  await sortByLikes();

  // Activity 10: Top 3 Trending Posts
  await trendingPosts();

  // Activity 11: Search Content matching text
  await searchContent('JavaScript');

  // Activity 12: Filter Posts having >= 100 Likes
  await filterHighLikes();

  // Activity 13: Display Latest Posts
  await displayLatestPosts();

  // Activity 14: Like a Post (Targeting ID 1)
  await likePost('1');

  // Activity 15: Combined Search + Filter
  await searchAndFilter('john', 'Programming');

  console.log("\n=== Testing Complete ===");
}

runDashboardTesting();