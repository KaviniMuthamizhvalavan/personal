import api from '../services/api.js';

// Helper to neatly print posts to console
const logPost = (post) => {
  console.log(`${post.username}`);
  console.log(`${post.content}`);
  console.log(`${post.category}`);
  console.log(`Likes: ${post.likes}`);
  if(post.hashtags) console.log(`Hashtags: ${post.hashtags}`);
  console.log('-------------------------');
};

// Activity 1 – View All Posts
export const viewAllPosts = async () => {
  try {
    const response = await api.get('/');
    console.log('\n--- Activity 1: View All Posts ---');
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error fetching all posts:', error.message);
  }
};

// Activity 2 - View Single Post
export const viewSinglePost = async (id) => {
  try {
    const response = await api.get(`/${id}`);
    console.log(`\n--- Activity 2: View Single Post (ID: ${id}) ---`);
    logPost(response.data);
  } catch (error) {
    console.error(`Error fetching post ${id}:`, error.message);
  }
};

// Activity 3 - Create New Post
export const createPost = async (newPost) => {
  try {
    const response = await api.post('/', newPost);
    console.log('\n--- Activity 3: Create New Post ---');
    console.log('Post Created Successfully');
    logPost(response.data);
  } catch (error) {
    console.error('Error creating post:', error.message);
  }
};

// Activity 4 – Update Existing Post
export const updatePost = async (id, updatedData) => {
  try {
    const response = await api.put(`/${id}`, updatedData);
    console.log(`\n--- Activity 4: Update Existing Post (ID: ${id}) ---`);
    console.log('Post Updated Successfully');
    logPost(response.data);
  } catch (error) {
    console.error(`Error updating post ${id}:`, error.message);
  }
};

// Activity 5 - Delete Post
export const deletePost = async (id) => {
  try {
    await api.delete(`/${id}`);
    console.log(`\n--- Activity 5: Delete Post (ID: ${id}) ---`);
    console.log('Post Deleted Successfully');
  } catch (error) {
    console.error(`Error deleting post ${id}:`, error.message);
  }
};

// Activity 6 - Search by Username
export const searchByUsername = async (username) => {
  try {
    const response = await api.get(`?username=${username}`);
    console.log(`\n--- Activity 6: Search by Username (${username}) ---`);
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error searching by username:', error.message);
  }
};

// Activity 7 - Search by Hashtag
export const searchByHashtag = async (hashtag) => {
  try {
    const response = await api.get(`?hashtags=${encodeURIComponent(hashtag)}`);
    console.log(`\n--- Activity 7: Search by Hashtag (${hashtag}) ---`);
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error searching by hashtag:', error.message);
  }
};

// Activity 8 – Filter by Category
export const filterByCategory = async (category) => {
  try {
    const response = await api.get(`?category=${category}`);
    console.log(`\n--- Activity 8: Filter by Category (${category}) ---`);
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error filtering by category:', error.message);
  }
};

// Activity 9 – Sort by Likes
export const sortByLikes = async () => {
  try {
    const response = await api.get('?_sort=likes&_order=desc');
    console.log('\n--- Activity 9: Sort by Likes ---');
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error sorting by likes:', error.message);
  }
};

// Activity 10 – Trending Posts (Top 3 Highest Likes)
export const trendingPosts = async () => {
  try {
    const response = await api.get('?_sort=likes&_order=desc&_limit=3');
    console.log('\n--- Activity 10: Trending Posts (Top 3) ---');
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error fetching trending posts:', error.message);
  }
};

// Activity 11 - Search Content
export const searchContent = async (query) => {
  try {
    const response = await api.get(`?q=${query}`);
    console.log(`\n--- Activity 11: Search Content Contains ("${query}") ---`);
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error searching content:', error.message);
  }
};

// Activity 12 - Filter Posts Having More Than 100 Likes
export const filterHighLikes = async () => {
  try {
    const response = await api.get('?likes_gte=100');
    console.log('\n--- Activity 12: Posts with >= 100 Likes ---');
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error filtering high likes:', error.message);
  }
};

// Activity 13 - Display Latest Posts
export const displayLatestPosts = async () => {
  try {
    const response = await api.get('?_sort=id&_order=desc&_limit=5');
    console.log('\n--- Activity 13: Display Latest 5 Posts ---');
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error fetching latest posts:', error.message);
  }
};

// Activity 14 – Like a Post
export const likePost = async (id) => {
  try {
    console.log(`\n--- Activity 14: Liking Post (ID: ${id}) ---`);
    
    // 1. Fetch post by ID
    const getResponse = await api.get(`/${id}`);
    const post = getResponse.data;
    console.log(`Before Likes : ${post.likes}`);
    
    // 2. Increase likes by 1
    post.likes += 1;
    
    // 3. Update the post via PUT or PATCH
    const putResponse = await api.put(`/${id}`, post);
    console.log(`After Likes : ${putResponse.data.likes}`);
  } catch (error) {
    console.error(`Error liking post ${id}:`, error.message);
  }
};

// Activity 15 – Search + Filter Together
export const searchAndFilter = async (username, category) => {
  try {
    const response = await api.get(`?username=${username}&category=${category}`);
    console.log(`\n--- Activity 15: Search + Filter Together (${username} + ${category}) ---`);
    response.data.forEach(logPost);
  } catch (error) {
    console.error('Error executing multi-filter search:', error.message);
  }
};