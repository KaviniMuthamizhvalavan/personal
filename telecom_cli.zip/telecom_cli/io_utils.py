import json
import csv
import logging
from models import Subscriber

logger = logging.getLogger(__name__)

def parse_cdr_line(row: dict) -> dict:
    try:
        clean_row ={
            "msisdn" : str(row["msisdn"]).strip(),
            "call_type" : str(row["call_type"]).strip().lower(),
            "duration_sec" : int(row["duration_sec"])
        }
        return clean_row
    except(KeyError, ValueError) as e:
        raise ValueError(f"Malformed or missing data in row: {e}")

def parse_legacy_line(line:str)->dict:
    parts = line.strip().split("|")
    return{
        "msisdn" : parts[0].strip(),
        "call_type" : parts[1].strip(),
        "duration_sec" : int(parts[2].strip())
    }

def load_subscribers(json_path:str)->dict:
    subscribers = {}
    with open(json_path, 'r') as file:
        data = json.load(file)
        for item in data:
            subscribers[item["msisdn"]] = Subscriber(item["msisdn"], item.get("plan_type", "prepaid"))
    return subscribers

def load_cdrs(csv_path:str) -> tuple:
    valid_cdrs = []
    total_rows = 0
    malformed_rows = 0
    with open(csv_path, 'r') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            total_rows+=1
            try:
                valid_cdrs.append(parse_cdr_line(row))
            except ValueError as e:
                malformed_rows+=1
                logging.warning(f"Skipping malformed row {total_rows}: {e}")
    return valid_cdrs, total_rows, malformed_rows

def write_report(report: dict, output_path: str) -> None:
    try:
        with open(output_path, 'w') as f:
            json.dump(report, f)
        logger.info(f"Report written successfully to {output_path}")
    except Exception as e:
        logger.error(f"Failed to write report to {output_path}: {e}")
        raise