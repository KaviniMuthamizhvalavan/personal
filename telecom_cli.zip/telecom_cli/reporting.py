from typing import Dict, List, Set
from models import Subscriber

def build_report(
    subscribers: Dict[str, Subscriber], 
    unknown_msisdns: Set[str], 
    fraud_suspects: List[Dict]
) -> dict:
    
    subscriber_reports = []
    for msisdn, sub in subscribers.items():
        subscriber_reports.append({
            "msisdn": msisdn,
            "plan_type": sub.plan_type,
            "call_count": len(sub.calls),
            "total_cost": sub.total_cost()
        })
        
    return {
        "subscribers": subscriber_reports,
        "unknown_subscribers": list(unknown_msisdns),
        "fraud_suspects": fraud_suspects
    }