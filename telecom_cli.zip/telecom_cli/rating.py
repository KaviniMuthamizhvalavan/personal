from config import RATES
def compute_cost(call_type: str, duration_sec: int) -> float:
    '''
    duration_min = duration_sec / 60.0

    if call_type == "domestic":
        rate = 1.5
    elif call_type == "roaming":
        rate = 8.0
    elif call_type == "international":
        rate = 12.0
    else:
        rate = 1.5

    return round(duration_min * rate,2) 
    '''
    rate = RATES.get(call_type.lower(), RATES["domestic"])
    return round((duration_sec / 60.0) * rate, 2)
