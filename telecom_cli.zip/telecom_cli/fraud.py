from config import DEFAULT_FRAUD_THRESHOLD_SEC
def is_suspicious(call_type: str, duration_sec: int, cost: float, threshold_sec: int = DEFAULT_FRAUD_THRESHOLD_SEC) -> bool:
    if duration_sec > 0 and cost == 0.0:
        return True
    if call_type.lower() == "international" and duration_sec > threshold_sec:
        return True
    return False