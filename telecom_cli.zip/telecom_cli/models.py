from typing import List,Dict

class Subscriber:
    def __init__(self, msisdn:str, plan_type:str):
        self.msisdn = msisdn
        self.plan_type = plan_type
        self.calls: List[Dict] = []

    def total_cost(self) -> float:
        return round(sum(call.get("cost", 0.0) for call in self.calls), 2)

class CDR:
    def __init__(self, msisdn:str, call_type: str, duration_sec:int, cost: float = 0.0):
        self.msisdn = msisdn
        self.call_type = call_type
        self.duration_sec = duration_sec
        self.cost = cost