#rate table
RATES = {
    'domestic': 1.5,
    'international': 12.0,
    'roaming': 8.0
}

DEFAULT_FRAUD_THRESHOLD_SEC = 3600