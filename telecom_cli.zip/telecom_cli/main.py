import argparse
import logging
import sys
from datetime import datetime

from config import DEFAULT_FRAUD_THRESHOLD_SEC
from io_utils import load_subscribers, load_cdrs, write_report
from rating import compute_cost
from fraud import is_suspicious
from reporting import build_report

def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

def main():
    setup_logging()
    logger = logging.getLogger(__name__)

    print(f"=== Telecom CDR & Billing Insights CLI | {datetime.now().strftime('%Y-%m-%d')} ===")

    parser = argparse.ArgumentParser(description="Process daily telecom CDRs.")
    parser.add_argument("--subscribers", required=True, help="Path to master subscribers JSON")
    parser.add_argument("--cdrs", required=True, help="Path to raw CDRs CSV")
    parser.add_argument("--output", required=True, help="Path to write the report JSON")
    parser.add_argument("--fraud-threshold-sec", type=int, default=DEFAULT_FRAUD_THRESHOLD_SEC, 
                        help="Threshold for international calls in seconds (default: 3600)")

    args = parser.parse_args()

    logger.info("Loading subscriber master list...")
    try:
        subscribers = load_subscribers(args.subscribers)
    except Exception as e:
        logger.error(f"Failed to load subscribers: {e}")
        sys.exit(1)

    logger.info("Loading CDR batch...")
    try:
        valid_cdrs, total_rows, malformed_rows = load_cdrs(args.cdrs)
    except Exception:
        sys.exit(1)

    if total_rows == 0:
        logger.error("No data found in CDR file.")
        sys.exit(1)

    malformed_pct = (malformed_rows / total_rows) * 100
    if malformed_pct > 20.0:
        logger.critical(f"Batch rejected: {malformed_pct:.1f}% malformed rows exceeds 10% limit.")
        sys.exit(1)

    logger.info("Processing CDR rating and anomaly detection...")
    unknown_msisdns = set()
    fraud_suspects = []

    for cdr in valid_cdrs:
        msisdn = cdr["msisdn"]
        call_type = cdr["call_type"]
        duration = cdr["duration_sec"]

        cost = compute_cost(call_type, duration)
        cdr["cost"] = cost

        if is_suspicious(call_type, duration, cost, args.fraud_threshold_sec):
            fraud_suspects.append(cdr)

        if msisdn not in subscribers:
            unknown_msisdns.add(msisdn)
        else:
            subscribers[msisdn].calls.append(cdr)

    logger.info("Building and writing final report...")
    report = build_report(subscribers, unknown_msisdns, fraud_suspects)
    
    write_report(report, args.output)

    print("\n--- Daily Batch Summary ---")
    print(f"Total CDRs Processed: {total_rows}")
    print(f"Malformed Rows Skipped: {malformed_rows} ({malformed_pct:.2f}%)")
    print(f"Unknown Subscribers Found: {len(unknown_msisdns)}")
    print(f"Fraud Suspects Flagged: {len(fraud_suspects)}")
    print(f"Report successfully saved to: {args.output}")

if __name__ == "__main__":
    main()